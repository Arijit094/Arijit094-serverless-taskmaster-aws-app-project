
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'arijit094',
  applicationName: 'serverless-taskmaster-aws-app',
  appUid: 'DMjYkQdy6K59W4jS9b',
  orgUid: '54c79303-8f5b-4397-a562-b3b4052c4d03',
  deploymentUid: 'f32eff01-8a0f-4776-a856-4232be56a786',
  serviceName: 'serverless-taskmaster-aws-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-taskmaster-aws-app-dev-kaamBharo', timeout: 6 };

try {
  const userHandler = require('./src/kaamBharo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}